g++ -I. tutorial02.cpp -o tutorial02 common/shader.cpp -lGLEW -lGL -lglfw
